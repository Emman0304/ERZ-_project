-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2022 at 04:14 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `user_name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `poc`
--

CREATE TABLE `poc` (
  `id` int(11) NOT NULL,
  `PRno` varchar(255) NOT NULL,
  `PRitem` varchar(255) NOT NULL,
  `PRnonitem` varchar(255) NOT NULL,
  `PGR` bigint(20) NOT NULL,
  `CR` varchar(255) NOT NULL,
  `RB` varchar(255) NOT NULL,
  `trackno` varchar(255) NOT NULL,
  `plantx3` varchar(255) NOT NULL,
  `ReqD` varchar(255) NOT NULL,
  `RelD` varchar(255) NOT NULL,
  `AcctAss` varchar(255) NOT NULL,
  `POno` bigint(255) NOT NULL,
  `POtem` bigint(255) NOT NULL,
  `POD` varchar(255) NOT NULL,
  `POdelD` varchar(255) NOT NULL,
  `materialx3` varchar(255) NOT NULL,
  `ST` varchar(255) NOT NULL,
  `QT` bigint(255) NOT NULL,
  `unitx3` varchar(255) NOT NULL,
  `VC` bigint(255) NOT NULL,
  `VN` varchar(255) NOT NULL,
  `telno` bigint(20) NOT NULL,
  `QTYREQ` bigint(255) NOT NULL,
  `GR103` varchar(255) NOT NULL,
  `GR101105` varchar(255) NOT NULL,
  `GR102104106` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `poc`
--

INSERT INTO `poc` (`id`, `PRno`, `PRitem`, `PRnonitem`, `PGR`, `CR`, `RB`, `trackno`, `plantx3`, `ReqD`, `RelD`, `AcctAss`, `POno`, `POtem`, `POD`, `POdelD`, `materialx3`, `ST`, `QT`, `unitx3`, `VC`, `VN`, `telno`, `QTYREQ`, `GR103`, `GR101105`, `GR102104106`) VALUES
(2, '1400424506', '10', '140042450610', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '08-16-22', 'MRP', 4100301531, 10, '07-21-22', '08-06-22', 'E0102039', 'STEEL, SHAFT 4140 Ø 60 x 1600 25-35HRC*', 1600, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 34, '7/29/2022', '7/26/2022', '7/27/2022'),
(3, '1400424556', '10', '140042455610', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 20, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3, '07/25/2022', '7/26/2022', '7/25/2022'),
(4, '1400424557', '10', '140042455710', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 30, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '07/25/2022', '7/26/2022', ''),
(5, '1400424558', '10', '140042455810', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 40, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '07/25/2022', '7/26/2022', ''),
(6, '1400424559', '10', '140042455910', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 50, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '07/25/2022', '7/26/2022', ''),
(7, '1400424560', '10', '140042456010', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 60, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 1, '07/25/2022', '7/26/2022', ''),
(8, '1400424561', '10', '140042456110', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 70, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3, '07/25/2022', '7/26/2022', ''),
(9, '1400424562', '10', '140042456210', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 80, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3, '07/25/2022', '7/26/2022', ''),
(10, '1400424563', '10', '140042456310', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 90, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 4, '07/25/2022', '7/26/2022', ''),
(11, '1400424564', '10', '140042456410', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 100, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3, '07/25/2022', '7/26/2022', ''),
(12, '1400424571', '10', '140042457110', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '09-05-22', 'MRP', 4100301531, 110, '07-21-22', '08-06-22', 'E0102032', 'STEEL, SHAFT 4140 Ø 20 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '07/25/2022', '7/26/2022', ''),
(13, '1400424592', '10', '140042459210', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '07-22-22', 'MRP', 4100301807, 20, '07-26-22', '08-13-22', 'E0102216', 'STEEL, SHAFT 4140 Ø 55 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 1, '', '', ''),
(14, '1400424606', '10', '140042460610', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-17-22', '07-22-22', 'MRP', 4100301856, 10, '07-27-22', '08-10-22', 'E0601099', 'STEEL, PLATE TS 1050 135 x 460 x 710*', 1, 'PC', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '', '', ''),
(15, '1400424978', '10', '140042497810', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 40, '07-26-22', '08-13-22', 'E3132228', 'STEEL, PLATE AISI D2 12 X 45 X 495 RM*', 8, 'PC', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 8, '', '', ''),
(16, '1400424995', '10', '140042499510', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 50, '07-26-22', '08-13-22', 'E0102035', 'STEEL, SHAFT 4140 Ø 35 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3048, '', '', ''),
(17, '1400424996', '10', '140042499610', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 60, '07-26-22', '08-13-22', 'E0102035', 'STEEL, SHAFT 4140 Ø 35 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3048, '', '', ''),
(18, '1400424997', '10', '140042499710', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 70, '07-26-22', '08-13-22', 'E0102035', 'STEEL, SHAFT 4140 Ø 35 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 4, '', '', ''),
(19, '1400424999', '10', '140042499910', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 80, '07-26-22', '08-13-22', 'E0102036', 'STEEL, SHAFT 4140 Ø 40 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 4, '', '', ''),
(20, '1400425000', '10', '140042500010', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 90, '07-26-22', '08-13-22', 'E0102036', 'STEEL, SHAFT 4140 Ø 40 x 3048 25-35HRC*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 3, '', '', ''),
(21, '1400425003', '10', '140042500310', 115, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '07-21-22', '07-21-22', 'MRP', 4100301807, 100, '07-26-22', '08-13-22', 'E0102056', 'STEEL, SHAFT TS 1045 Ø 25 x 3048*', 3048, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2, '', '', ''),
(22, '1400417750', '10', '140041775010', 0, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '', '05-15-22', '05-17-22', 'MRP', 4100302063, 10, '08-01-22', '08-17-22', 'E0102350', 'STEEL, SQ KEY BAR 4140 1\" x 1\" x 5305*', 2438, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2438, '', '', ''),
(23, '1400417751', '10', '140041775110', 0, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '', '05-15-22', '05-17-22', 'MRP', 4100302063, 20, '08-01-22', '08-17-22', 'E0102350', 'STEEL, SQ KEY BAR 4140 1\" x 1\" x 5305*', 2438, 'MM', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 2438, '', '', ''),
(24, '1400424871', '10', '140042487110', 0, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '', '', '', 4100302315, 40, '08-05-22', '08-19-22', '', 'STEEL, PLATE H13 70 x 110 x 375 30-35HR*', 12, 'PC', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 9, '', '', ''),
(25, '1400424870', '10', '140042487010', 0, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '', '', '', 4100302315, 30, '08-05-22', '08-19-22', '', 'STEEL, PLATE H13 70 x 110 x 375 30-35HR*', 9, 'PC', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 9, '', '', ''),
(26, '1400424868', '10', '140042486810', 0, 'RTI Planner', 'RTI Planner', 'RTIWHSEMB', '400A', '', '', '', 4100302315, 10, '08-05-22', '08-19-22', '', 'STEEL, PLATE H13 70 x 110 x 350 30-35HR*', 12, 'PC', 203456, 'A.C. EDELSTAHL AND INDUSTRIAL', 9612789376, 10, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`, `name`, `department`) VALUES
(1, 'eljane', 'eljane', 'Eljane Zafra', 'IT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `poc`
--
ALTER TABLE `poc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `poc`
--
ALTER TABLE `poc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
