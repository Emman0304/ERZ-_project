<?php

	include("connection.php");
	if(isset($_POST['insert']))
	{
		$id = $_POST['update_id'];
		$POD = $_POST['POD'];
		$POdelD = $_POST['POdelD'];
		$telno = $_POST['telno'];
		$QTYREQ = $_POST['QTYREQ'];
		$GR103 = $_POST['GR103'];
		$GR101105 = $_POST['GR101105'];
		$GR102104106 = $_POST['GR102104106'];
		
		$query1 = "update poc set POD='$POD',POdelD='$POdelD',telno='$telno',QTYREQ='$QTYREQ',GR103='$GR103',GR101105='$GR101105',GR102104106='$GR102104106' where id='$id'";
		$query_run = mysqli_query($con,$query1);
		
		if($query_run)
		{
			header("Location: index.php");
		}
		else
		{
			echo '<script>alert("error")</script>';
		}
	}
?>