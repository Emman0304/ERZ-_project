<?php
session_start();

  include("connection.php");
  include("function1.php");
  
  $user_data = check_login($con);
 // require 'config.php';

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>SMIPS</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
    crossorigin="anonymous">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" href="">
    <link rel="stylesheet" type="text/css" href="table.css">
    
</head>
<body style="background-color: #ccccff";>



<!-- ++++++++++++++++ EDIT MODAL ++++++++++++++++ -->
            <!-- The Modal -->
        <div class="modal fade" id="editmodal">
          <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
            <h2 class="modal-title">EDIT DATA</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body" style="background-color:#ccccff">
              <div class="container mt-3">
      <!--        <h2>Please Fill Up</h2> -->
              <form action="update.php" method = "post">
                <input type="hidden" name="update_id" id="update_id">
                <div class="mb-1 mt-1">
                
                <label>PO DATE:</label>
                <input type="text" class="form-control" id="POD" placeholder="" name="POD">
                </div>
                
                <div class="mb-1 mt-1">
                <label>PO DELIVERY DATE:</label>
                <input type="text" class="form-control" id="POdelD" placeholder="" name="POdelD">
                </div>
                
                <div class="mb-1 mt-1">
                <label>COMPANY CONTACT:</label>
                <input type="text" class="form-control" id="telno" placeholder="" name="telno">
                </div>
                
                <div class="mb-1 mt-1">
                <label>QTY DELIVERED:</label>
                <input type="text" class="form-control" id="QTYREQ" placeholder="" name="QTYREQ">
                </div>
                
                <div class="mb-1 mt-1">
                <label>GR 103:</label>
                <input type="text" class="form-control" id="GR103" placeholder="" name="GR103">
                </div>
                
                <div class="mb-1 mt-1">
                <label>GR 101/105</label>
                <input type="text" class="form-control" id="GR101105" placeholder="" name="GR101105">
                </div>

                <div class="mb-1 mt-1">
                <label>GR 102/104/106</label>
                <input type="text" class="form-control" id="GR102104106" placeholder="" name="GR102104106">
                </div>
                
                <button type="submit" class="btn btn-primary" name="insert">Update</button>
              </form>
              </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
            <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
            </div>

          </div>
          </div>
        </div>


<!-- ++++++++++++++++ EDIT MODAL END ++++++++++++++++ -->


<div class="container mt-3">
    <!--    <img class="mb-4" src="smip.jpg" alt="" width="150" height="150"> -->
   <h1 style=" font-size: 45px; color: rgb(0,102,51); text-align: left; font-family: 'Tahoma', 'Arial Narrow', Arial, sans-serif; font-weight: bold;">SMIP</h1>
   <h2  style="font-size: 60px; color: rgb(0,0,102); text-align: left; font-family: 'Tahoma', 'Arial Narrow', Arial, sans-serif; font-weight: bold;">SPD - OCB</h2>
   <h3 style=" font-size: 45px; color: #000000; text-align: left; font-family: 'Tahoma', 'Arial Narrow', Arial, sans-serif; font-weight: bold;">PROCUREMENT</h3>
<br>
  <div class="container box">
   <form method="post" enctype="multipart/form-data">

    <input type="file" name="excel" /><br>
    <h5 style="font-size:1px"></h5>
    <input style="background-color: #0000ff; color:white; "type="submit" name="import" class="btn btn-info" value="IMPORT EXCEL" />
   </form>
   <br />

  </div>

  <!-- Start of the table-->
  <table class="table table-hover" id="datatableid">
    <thead>
      <tr style="background-color:#0000ff">

    <th>ID</th>
      <th>PURCH.REQ</th>
        <th>ITEM</th>
    <th>PR&nbsp;/&nbsp;ITEM</th>
    <th>PGr</th>
    <th>CREATED&nbsp;BY</th>
    <th>REQUESTED&nbsp;BY</th>
    <th>TRACKING&nbsp;NO.</th>
    <th>PLANT</th>
    <th>REQUEST&nbsp;DATE</th>
    <th>RELEASE&nbsp;DATE</th>
    <th>ACCT&nbsp;ASS</th>
    <th>PO&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>ITEM</th>
    <th>PO&nbsp;DATE</th>
    <th>PO&nbsp;DEL&nbsp;DATE</th>
    <th>MATERIAL</th>
    <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SHORT&nbsp;TEXT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>QTY</th>
    <th>UN</th>
    <th>V.CODE&nbsp;&nbsp;</th>
    <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;VENDOR&nbsp;NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> 
    <th>CONTACT&nbsp;&nbsp;</th>
    <th>DUEDATE&nbsp;</th>  
    <th>QTY&nbsp;DEV</th>
    <th>DEV&nbsp;STAT</th>  
    <th>REMARKS</th>
    <th>GR103</th>    
    <th>GR101/105</th>
    <th>GR102/104/106</th>    
    <th>HIT/MISS</th>
    <th>ACTION</th>
      </tr>
    </thead>

    <tbody>
    <?php
    
      $query = "select * from poc";
      $result = mysqli_query($con,$query);

      
      while ($row=mysqli_fetch_array($result))
      {
                $remarks;
                $devStatus;
                $hitMiss;
                $dueDate;

                $dateToday =date("m/d/Y");
                $POdelD=$row["POdelD"];
                $dateToday1 = strtotime($dateToday);
                $POdelD1 = strtotime($POdelD);
                $defDue='00/00/0000';
                $defDue1=strtotime($defDue);

                $date101=$row["GR101105"];
                $newDate101=strtotime($date101);

                $gr103=$row["GR103"];
                $gr106=$row["GR102104106"];
                $new103=strtotime($gr103);
                $new106=strtotime($gr106);
                $defTime='00/00/0000';
                $newDefTime=strtotime($defTime);

              if (!empty($row["QT"])&& !empty($row["QTYREQ"]) ) {
                if ($row["QT"] > $row["QTYREQ"]) {
                  $remarks="In Partial";
                }elseif ($row["QT"] == $row["QTYREQ"]) {
                  $remarks="Completed";
                }else{
                  $remarks="Completed";
                }
              }else{
                $remarks=" ";
              }

                
            if (!empty($POdelD1)) {
                if($dateToday1 > $POdelD1){
                    $dueDate="OVER DUE";
                  }elseif($dateToday1 < $POdelD1){
                    $dueDate="NOT DUE";
                  }elseif($dateToday1 === $POdelD1){
                    $dueDate="DUE TODAY";
                  }
              }else{
                $dueDate=" ";
              }  
              
            
              if(!empty($POdelD1) && !empty($newDate101)){
                  if($POdelD1 > $newDate101 ){
                        $hitMiss="HIT";
                    }elseif($POdelD1 == $newDate101){
                        $hitMiss="HIT";
                    }else{
                        $hitMiss="MISS";
                }
              }else{
                $hitMiss=" ";
              }
                

              if (!empty($new103) && !empty($newDate101) && !empty($new106)) {
                if($new103 > $newDate101 && $new103 > $new106){
                    $devStatus="INCOMING";
                }elseif ($newDate101 > $new103 && $newDate101 > $new106 || $newDate101 > $new106 && $newDate101 == $new103 ) {
                    $devStatus="DELIVERED";
                }elseif ($new106 > $newDate101 && $new106 > $new103 || $new106 > $newDate101 && $new106 == $new103 || $newDate101 > $new103 && $new106 == $newDate101 ) {
                    $devStatus="REJECTED";
                }else{
                    $devStatus = "FOLLOW-UP";
                }
              }else{
                $devStatus = " ";
              }
                

    ?>

                      
      <tr style="background-color: #ffffff; font-size: 13px">
    <td><?php echo $row["id"];?></td>
    <td><?php echo $row["PRno"];?></td>       
    <td><?php echo $row["PRitem"];?></td>
    <td><?php echo $row["PRnonitem"];?></td> 
    <td><?php echo $row["PGR"];?></td>
    <td><?php echo $row["CR"];?></td>
    <td><?php echo $row["RB"];?></td>
    <td><?php echo $row["trackno"];?></td>
    <td><?php echo $row["plantx3"];?></td>
    <td><?php echo $row["ReqD"];?></td> 
    <td><?php echo $row["RelD"];?></td>
    <td><?php echo $row["AcctAss"];?></td>
    <td><?php echo $row["POno"];?></td>
    <td><?php echo $row["POtem"];?></td>
    <td><?php echo $row["POD"];?></td>
    <td><?php echo $row["POdelD"];?></td> 
    <td><?php echo $row["materialx3"];?></td>
    <td><?php echo $row["ST"];?></td>
    <td style="text-align: right"><?php echo $row["QT"];?></td>
    <td style="text-align: left"><?php echo $row["unitx3"];?></td>
    <td><?php echo $row["VC"];?></td>
    <td><?php echo $row["VN"];?></td> 
    <td><?php echo $row["telno"];?></td>
    <td><?php echo $dueDate ?></td>
    <td><?php echo $row["QTYREQ"];?></td>
    <td><?php echo $devStatus ?></td>
    <td><?php echo $remarks ?></td>
    <td><?php echo $row["GR103"];?></td>
    <td><?php echo $row["GR101105"];?></td>
    <td><?php echo $row["GR102104106"];?></td>  
    <td><?php echo $hitMiss ?></td>
    <td> 
      <div class="btn-group">
        <button style="background-color:  #9400D3""; type="button" class="btn btn-primary editbtn">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"></path>
        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"></path>
        </svg>
        </button>
        
        <a href="delete1.php?id=<?php echo $row['id'];?>" type="button" class="btn btn-danger">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
        <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"></path>
        </svg>
        </a>
      <?php
      }
      ?>
      </div>  
    </td>
      </tr>
    </tbody>
  </table>
  <! -- End of the table-->
    <a href="LogOut1.php" type="button" class="btn btn-dark mt-3 float-end">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
    <path d="M7.5 1v7h1V1h-1z"></path>
    <path d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z"></path>
    </svg>
    Logout
    </a>
    
    <!-- <a href="adminOption.php" type="button" class="btn btn-primary mt-3 float-end">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
    <path d="M7.5 1v7h1V1h-1z"></path>
    <path d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z"></path>
    </svg>
    Back to admin Panel
    </a> -->
</div>
  
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" 
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

    <script>
      $(document).ready(function () {
        
      $('#datatableid').DataTable({
      "pagingType": "full_numbers",
      "lengthMenu": [
      [10000, 25000, 50000, -1],
      [10000, 25000, 50000, "All"]
      ],
      responsive: true,
      language: {
      search: "_INPUT_",
      searchPlaceholder: "Search Your Data",
      }
      });
      
      });
    </script>
<script>
  $(document).ready(function () {
  
  $('.editbtn').on('click', function (){
    
  $('#editmodal').modal('show');
  
  $tr = $(this).closest('tr');
  
  var data = $tr.children("td").map(function (){
  return $(this).text();
  }).get();
  
  console.log(data);
  
  $('#update_id').val(data[0]);
  $('#POD').val(data[14]);
  $('#POdelD').val(data[15]);
  $('#telno').val(data[22]);
  $('#QTYREQ').val(data[24]);
  $('#GR103').val(data[27]);
  $('#GR101105').val(data[28]);
  $('#GR102104106').val(data[29]);
  });
  });

</script>

<?php
    if(isset($_POST["import"])){
      $fileName = $_FILES["excel"]["name"];
      $fileExtension = explode('.', $fileName);
      $fileExtension = strtolower(end($fileExtension));
      $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

      $targetDirectory = "uploads/" . $newFileName;
      move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

      error_reporting(0);
      ini_set('display_errors', 0);

      require 'excelReader/excel_reader2.php';
      require 'excelReader/SpreadsheetReader.php';

      $reader = new SpreadsheetReader($targetDirectory);
      foreach($reader as $key => $row){
        $PRno = $row[0];
        $PRitem = $row[1];
        $PRnonitem = $row[2]; 
        $PGR = $row[3];
        $CR = $row[4];
        $RB = $row[5];
        $trackno = $row[6];
        $plantx3 = $row[7];
        $ReqD = $row[8];
        $RelD = $row[9];
        $AcctAss = $row[10];
        $POno = $row[11];
        $POtem = $row[12];
        $POD = $row[13];
        $POdelD = $row[14];
        $materialx3 = $row[15];
        $ST = $row[16];
        $QT = $row[17];
        $unitx3 = $row[18];
        $VC = $row[19];
        $VN = $row[20];
        $telno = $row[21];
        $QTYREQ = $row[22];
        $GR103 = $row[23];
        $GR101105 = $row[24];
        $GR102104106 = $row[25];

  
        mysqli_query($con, "INSERT INTO poc VALUES('', '$PRno', '$PRitem', '$PRnonitem','$PGR', '$CR', '$RB', '$trackno', '$plantx3', '$ReqD','$RelD', '$AcctAss', '$POno', '$POtem', '$POD', '$POdelD','$materialx3', '$ST', '$QT','$unitx3', '$VC', '$VN', '$telno', '$QTYREQ', '$GR103', '$GR101105', '$GR102104106')");
      }

      echo
      "
      <script>
      alert('Succesfully Imported');
      document.location.href = '';
      </script>
      ";
    }

?>
</body>
</html>