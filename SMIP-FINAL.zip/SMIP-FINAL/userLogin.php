<?php 
	
	session_start();
		include("connection.php");
		include("function1.php");
	
	if( $_SERVER['REQUEST_METHOD'] == "POST") {   //// GETING INPUT FROM ENTITY NAME BELOW TO PHP
	
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if (!empty($user_name) && !empty($password)) {
			// read to data base

			$query = "select * from users where user_name = '$user_name' limit 1 " ;

			$result = mysqli_query($con,$query);
			
			if ($result) {
				if ($result && mysqli_num_rows($result) >0 ) {
					
					$user_data = mysqli_fetch_assoc($result);

					if ($user_data['password'] === $password) {
						$_SESSION['user_id']=$user_data['user_id'];
						header("Location: index1.php");
						die;
					}
				}
			}
			echo "<script>alert('Incorrect Username/Password')</script>";
		}
		echo "<script>alert('Please, complete input fields.')</script>";
	}
			
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>USER LOGIN</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	
	 <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
	
	<!-- Custom styles for this template -->
    <link href="logDes.css" rel="stylesheet">
	
</head>
  <body style="background-color: #ffffff" class="text-center">
	<main class="form-signin">
	<form method ="post">
<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

<div style="  background: rgb(104, 103, 103);"class="login">

  <form>
   	<img class="mb-4" src="smip.jpg" alt="" width="200" height="200">
    
				<h1 class="h3 mb-3 fw-normal">USER | L O G I N</h1>
				
				<div class="mb-3 mt-3">
				  <input type="text" class="form-control" id="floatingInput" placeholder="User Name" name="user_name">
				</div>

				<div class="mb-3 mt-3">
					<input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
				</div>						
				<div class="mb-3 mt-3">
					<button  style="background-color: #2e2e1f; border-color:#FFFFFF; color:white" class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
				
				<br>
				<a href = "login.php"> Sign in as ADMIN</a>
				</div>
				
	
	
	

    <hr>
  </form>
</div>
		  </form>
	</main> 

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>