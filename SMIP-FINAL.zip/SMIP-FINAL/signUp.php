<?php 
	
	session_start();
		include("connection.php");
		include("function.php");
		$user_data = check_login($con);
	
	if( $_SERVER['REQUEST_METHOD'] == "POST") {   //// GETING INPUT FROM ENTITY NAME BELOW TO PHP
	
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];
		$name = $_POST['name'];
		$department = $_POST['department'];
		$passConfirm = $_POST['password_confirm'];

		if (!empty($user_name) && !empty($password) && !empty($name) && !empty($department)) {
			// save to data base
			// $user_id = random_num(20);   
			if($password === $passConfirm ){   
			$query = "insert into users(user_id,user_name,password,name,department) values ('$user_id','$user_name','$password','$name','$department')"; 

			mysqli_query($con,$query);

			header("Location: adminOption.php");
			die;
			}
			echo "<script>alert('Password do not matched.')</script>";
		}
		else
		{
			echo "<script>alert('Incomplete Details, Complete input fields.')</script>";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Create User</title>

	<style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

	<link href="des.css" rel="stylesheet">

</head>
<body style="background-color: #ffffff"  class="text-center">
	<main class="form-signup">
	<form method ="post">
<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

<div class="margin">
		
</div>

<div class="login">

  <form>
   	<img class="mb-4" src="smip.jpg" alt="" width="170" height="170">
    
				<h1 class="h3 mb-3 fw-normal">ADMIN | ADD USER</h1>
				
				<div class="mb-3 mt-3">
				  <input type="text" class="form-control" id="floatingInput" placeholder="Name" name="name">
				</div>
				<div class="mb-3 mt-3">
				  <input type="text" class="form-control" id="floatingInput" placeholder="User Name" name="user_name">
				</div>
				<div class="mb-3 mt-3">
				  <input type="text" class="form-control" id="floatingInput" placeholder="Department" name="department">
				</div>
				<div class="mb-3 mt-3">
					<input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
				</div>
				<div class="mb-3 mt-3">
					<input type="password" class="form-control" id="floatingPassword" placeholder="Confirm Password" name="password_confirm">
				</div>						
				<div class="mb-3 mt-3">
					<button style="background-color: #0000ff""; border-color:#FFFFFF"; color:white" class="w-100 btn btn-lg btn-primary" type="submit">Register</button>
			
				<br>
				<a href = "adminOption.php"> Back to Admin Panel </a>
				</div>
				
	
	
	

    <hr>
  </form>
</div>
		  </form>
	</main> 

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>