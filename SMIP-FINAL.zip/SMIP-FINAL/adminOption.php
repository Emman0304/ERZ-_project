<?php
session_start();

  include("connection.php");
  include("function.php");
  
  $user_data = check_login($con);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Amin Control Panel</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="adOpDes.css">
</head>
<body style="background-color: #ffffff"; class="text-center" >

<div class="container">
   <div class="row" style="margin-top:45px">
    <img class="mb-4" src="smip.jpg" alt="" width="200" height="200">
    <h1 class="h3 mb-3 fw-normal">Admin Control Panel</h1>        
              <div class="form-group">
                <a href="index.php" class="btn btn-primary" >DASHBOARD</a>
              </div>
              <div class="form-group">
                <a href="signUp.php" class="btn btn-primary" >CREATE NEW USER</a>
              </div>
              <div class="form-group">
                <a href="userIndex.php" class="btn btn-primary" >LIST OF USERS</a>
              </div>
              <div class="form-group">
                <a href="logout.php" class="btn btn-danger" >LOGOUT</a>
              </div>
   </div>
</div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>