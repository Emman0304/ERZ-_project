<?php

	include("connection.php");
	
	$id = $_GET['id'];
	$query3 = "delete from poc where id=$id" ;
	$query_run = mysqli_query($con,$query3);
	
	if($query_run)
		{
			header("Location: index1.php");
		}
		else
		{
			echo '<script>alert("error")</script>';
		}
?>